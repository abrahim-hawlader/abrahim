
package ComputerSystem;


public class SimpleComputer {
        public static void add(int a, int b)
    {
        System.out.println("Summation: " + (a+b));
    }

    public static void sub(int a, int b)
    {
        System.out.println("Result: " + (a - b));
    }
    
}
