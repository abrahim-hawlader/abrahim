
import java.util.Scanner;
import java.util.ArrayList;

import ComputerSystem.AdvancedComputer;
import LearnerSystem.LearnerForm;
import Utils.PrepareForm;
import Utils.ComputerServices;
import Utils.LearnerServiceMsg;
import Utils.CRUDServices;
import Utils.SystemService;
        



public class StructureManager {

 
    public static void main(String[] args) {
        
        ArrayList<LearnerForm> Database = new ArrayList<>();
        int option;
        int operation;
           SystemService ss;
        ss = new LearnerServiceMsg();

        SystemService cs;
        cs = new ComputerServices();
        
        
         while(true)
        {
            System.out.println("\n\n Welcome to our Structure Management System !!!\n");
            System.out.println("1. Learner Services");
            System.out.println("2. Computer Services");
            System.out.println("0. Terminate\n");

            Scanner scan = new Scanner(System.in);

            System.out.print("Enter Option: ");
            option = scan.nextInt();

            if (option == 0)
                break;

            switch (option) {
                case 1 -> {
                    ss.greeting_msg();
                    while (true)
                    {
                        ss.service_info();
                        System.out.print("Enter Operation: ");
                        operation = scan.nextInt();
                        
                        if (operation == 0)
                            break;
                        
                        // create | read | update | delete
                        switch (operation)
                        {
                            case 1 ->  
                                // create
                            
                            { 
                                LearnerForm std = PrepareForm.fillUp();
                                CRUDServices.create(std, Database);
                            }
                            case 2 ->    
                                // read
                            
                            { 
                                System.out.print("Search Id: ");
                                int search_id = scan.nextInt();
                                CRUDServices.filterById(search_id, Database);
                            }
                            case 3 ->
                                // update
                            { 
                                System.out.print("Update through id: ");
                                LearnerForm update_std = PrepareForm.fillUp();
                                CRUDServices.update(update_std, Database);
                            }
                            case 4 ->  
                                // delete
                            
                            { 
                                System.out.print("Delete Id: ");
                                int delete_id = scan.nextInt();
                                CRUDServices.delete(delete_id, Database);
                            }
                            default -> System.out.println("Invalid Operation");
                        }
                    }   ss.terminate_msg();
                }
                case 2 -> {
                    cs.greeting_msg();
                    while (true)
                    {
                        double num1, num2;
                        int a, b, c;
                        
                        cs.service_info();
                        System.out.print(" Enter NO. of Services : ");
                        operation = scan.nextInt();
                        
                        if (operation == 0)
                            break;
                        
                        // addition | subtraction | multiplication | division
                        switch (operation)
                        {
                            case 1 ->       
                                // addition
                                
                            { 
                                System.out.print("Enter your 1st value: ");
                                a = scan.nextInt();
                                System.out.print("Enter your 2nd value: ");
                                b = scan.nextInt();
                                System.out.print("Enter your 3rd value: ");
                                c = scan.nextInt();
                                AdvancedComputer.add(a, b, c);
                            }
                            case 2 ->
                                // subtraction
                            {
                                System.out.print("Enter your 1st value: ");
                                a = scan.nextInt();
                                System.out.print("Enter your 2nd value: ");
                                b = scan.nextInt();
                                System.out.println("Enter Your 3rd Value: ");
                                c=scan.nextInt();
                                AdvancedComputer.sub(a, b,c);
                            }
                            case 3 ->
                                // multiplication
                            {
                                System.out.print("Enter your 1st value: ");
                                a = scan.nextInt();
                                System.out.print("Enter your 2nd value: ");
                                b = scan.nextInt();
                                System.out.println("Enter your 3rd Value : ");
                                c=scan.nextInt();
                               
                                AdvancedComputer.multiply(a, b,c);
                            }
                            case 4 ->
                                // division
                            {
                                System.out.print("Enter your 1st value: ");
                                num1 = scan.nextInt();
                                System.out.print("Enter your 2nd value: ");
                                num2 = scan.nextInt();
                                AdvancedComputer.div(num1, num2);
                            }
                            default -> System.out.println("Invalid Operation");
                        }
                    }   cs.terminate_msg();
                }
                default -> System.out.println("Invalid Options");
            }
        }
    
        
    }
    
}
