
package Utils;

public abstract class SystemService {
    public abstract void greeting_msg();
    public abstract void terminate_msg();
    public abstract void service_info();
    
}
