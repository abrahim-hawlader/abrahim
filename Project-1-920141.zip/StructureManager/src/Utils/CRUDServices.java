

package Utils;
import java.util.ArrayList;
import LearnerSystem.LearnerForm;
         
public class CRUDServices {
        // create | post
    public static void create(LearnerForm st, ArrayList<LearnerForm> Database)
    {
        for (LearnerForm learner: Database)
        {
            if (learner.ID == st.ID)
            {
                System.out.println("Id already exist");
                return;
            }
        }
        Database.add(st);
        System.out.println("Successfully added.");
    }

    // read | get
    public static void filterById(int id, ArrayList<LearnerForm> Database)
    {
        for (LearnerForm st: Database)
        {
            if (st.ID == id)
            {
                System.out.println("Learner Information:");
                System.out.println("Id              : " + st.ID);
                System.out.println("Name            : " + st.name);
                System.out.println("Age             : " + st.age);
                System.out.println("Department      : " + st.department);
                System.out.println("Admission Year  : " + st.admissionYear);
                System.out.println("Address         : " + st.getAddress());
                return;
            }
        }
        System.out.println("Learner Information Not Found in Database.");
    }

    // update
    public static void update(LearnerForm st, ArrayList<LearnerForm> Database)
    {
        int update_index = 0;
        for (LearnerForm learner: Database)
        {
            if (learner.ID == st.ID)
            {
                Database.remove(update_index);
                Database.add(st);
                return;
            }
            update_index ++;
        }
        System.out.println("Information Not Found in Database");
    }

    // delete
    public static void delete(int id, ArrayList<LearnerForm> Database)
    {
        int item_index = 0;
        for (LearnerForm st: Database)
        {
            if (st.ID == id) {
                Database.remove(item_index);
                return;
            }
            item_index ++;
        }
        System.out.println("Item Not Found in Database");
    }
    
}
