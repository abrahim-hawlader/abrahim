
package Utils;

public class LearnerServiceMsg extends SystemService {
     // Greetings message
    @Override
    public void greeting_msg()
    {
        System.out.println("\n Welcome to our Learner Services !!!");
    }

    // Ending message
    @Override
    public void terminate_msg()
    {
        System.out.println(" Terminating Learner Services");
    }

    // Student Services
    @Override
    
    public void service_info()
    {
        System.out.println("""
                           
                           Learner Services: 
                           # 1 Create
                           # 2 Read
                           # 3 Update
                           # 4 Delete
                           # 0 Terminate
                           """);
    }
    
    
    
}
