
package LearnerSystem;


public class LearnerForm {
    public int ID;
    public String name;
    public String department;
    public int age;
    public int admissionYear;
    private String contact;
    private String address;

    // constructor
    public LearnerForm(
            int id,
            String name,
            String department,
            int age,
            int admissionYear,
            String contact
    )
    {
        this.ID = id;
        this.name = name;
        this.department = department;
        this.age = age;
        this.admissionYear = admissionYear;
        this.contact = contact;
    }

    public String setContact(String contact) {
        if (String.valueOf(contact).length() == 12) {
            return contact;
        }
        else {
            return "Invalid Contact";
        }
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
}
